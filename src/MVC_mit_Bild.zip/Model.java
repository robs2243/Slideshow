import java.util.Observable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Model extends Observable {

  private int countDown;
  private Image img;

  public Model() {
    countDown = 10;
    img = null;
    
  }

  public int getCountDown() {
    return countDown;
  }

  public void tick() {
    
    if (countDown > 0) {
      countDown--;
      setChanged();
    }
    notifyObservers();
  
  }

 
  public Image getImage() {
      return img;
  }
  
  public void ladeBild(String pfadVomBild) {
  
      img = new Image(pfadVomBild);
      setChanged();  //geerbt - legt fest, dass das beochtbare Objekt geändert hat
      notifyObservers(); //geerbt - Beobachter benachrichten
        
  }
    
}
